package com.example.unipigrades;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public static final int ADD_NOTE_REQUEST=1;
    public static final int EDIT_NOTE_REQUEST=2;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
    String UID = user.getUid();

    DatabaseReference myRef=database.getReference("User_data").child(UID);
    private LiveData<List<Note>> allNotess;






private NoteViewModel noteViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        FloatingActionButton buttonAddnote = findViewById(R.id.button_add_note);   //declaring addnote and save buttons
        FloatingActionButton save_toFirebase = findViewById(R.id.save_toFirebase);
        buttonAddnote.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddEditNoteActivity.class);
                startActivityForResult(intent,ADD_NOTE_REQUEST);

                // on click listener to go to ADDNote page

            }
        });

        save_toFirebase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



             allNotess=   noteViewModel.getAllNotes();
              // GETs user unique ID


                myRef.setValue(allNotess).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(MainActivity.this, "Data Successfully saved!", Toast.LENGTH_SHORT).show();
                        }else if (task.getException() instanceof FirebaseAuthUserCollisionException){
                            Toast.makeText(MainActivity.this, "Data not saved!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });









            }
        });

        RecyclerView recyclerView= findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final NoteAdapter adapter = new NoteAdapter();
        recyclerView.setAdapter(adapter);

        noteViewModel = ViewModelProviders.of(this).get(NoteViewModel.class);
        noteViewModel.getAllNotes().observe(this, new Observer<List<Note>>() {
            @Override
            public void onChanged(@Nullable List<Note> notes) {
                adapter.submitList(notes);


            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT| ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                noteViewModel.delete(adapter.getNoteAt(viewHolder.getAdapterPosition()));

                Toast.makeText(MainActivity.this, "Note Deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);

        adapter.setOnItemClickListener(new NoteAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Note note) {
                Intent intent = new Intent(MainActivity.this, AddEditNoteActivity.class);
                intent.putExtra(AddEditNoteActivity.EXTRA_ID,note.getId());
                intent.putExtra(AddEditNoteActivity.EXTRA_TITLE, note.getTitle());
                intent.putExtra(AddEditNoteActivity.EXTRA_DESCRIPTION,note.getDescription());
                intent.putExtra(AddEditNoteActivity.EXTRA_PROJECTS, note.getProjects());
                intent.putExtra(AddEditNoteActivity.EXTRA_PRIORITY, note.getPriority());
                intent.putExtra(AddEditNoteActivity.EXTRA_GRADE, note.getGrade());
                intent.putExtra(AddEditNoteActivity.EXTRA_SEMESTER, note.getSemester());
                intent.putExtra(AddEditNoteActivity.EXTRA_ECTS, note.getEcts());

                startActivityForResult(intent, EDIT_NOTE_REQUEST);


            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==ADD_NOTE_REQUEST && resultCode==RESULT_OK){
            String title = data.getStringExtra(AddEditNoteActivity.EXTRA_TITLE);
            String description = data.getStringExtra(AddEditNoteActivity.EXTRA_DESCRIPTION);
            String projects = data.getStringExtra(AddEditNoteActivity.EXTRA_PROJECTS);
            int priority = data.getIntExtra(AddEditNoteActivity.EXTRA_PRIORITY, 1);
            int grade = data.getIntExtra(AddEditNoteActivity.EXTRA_GRADE,1);
            int semester = data.getIntExtra(AddEditNoteActivity.EXTRA_SEMESTER,1);
            int ects = data.getIntExtra(AddEditNoteActivity.EXTRA_ECTS,1);

            Note note = new Note(title,description,priority,grade,projects,semester,ects);
            noteViewModel.insert(note);

            Toast.makeText(this, "Note Saved", Toast.LENGTH_SHORT).show();

        }else if (requestCode==EDIT_NOTE_REQUEST && resultCode==RESULT_OK){

            int id= data.getIntExtra(AddEditNoteActivity.EXTRA_ID,-1);


            if (id==-1){
                Toast.makeText(this, "Note Cant be Updated!", Toast.LENGTH_SHORT).show();
                return;
            }

            String title = data.getStringExtra(AddEditNoteActivity.EXTRA_TITLE);
            String description = data.getStringExtra(AddEditNoteActivity.EXTRA_DESCRIPTION);
            String projects = data.getStringExtra(AddEditNoteActivity.EXTRA_PROJECTS);
            int priority = data.getIntExtra(AddEditNoteActivity.EXTRA_PRIORITY, 1);
            int grade = data.getIntExtra(AddEditNoteActivity.EXTRA_GRADE,1);
            int semester = data.getIntExtra(AddEditNoteActivity.EXTRA_SEMESTER,1);
            int ects = data.getIntExtra(AddEditNoteActivity.EXTRA_ECTS,1);


            Note note= new Note(title,description,priority,grade,projects,semester,ects);
            note.setId(id);
            noteViewModel.update(note);

            Toast.makeText(this, "Note Updated!", Toast.LENGTH_SHORT).show();



        } else {
            Toast.makeText(this, "Note Not Saved", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater= getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.delete_all_notes:
                noteViewModel.deleteAllNotes();
                Toast.makeText(this, "All notes deleted", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.menuLogout:
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(this, "Logout was successful!", Toast.LENGTH_SHORT).show();
                finish();
                startActivity(new Intent(this,LoginActivity.class));

           // case R.id.main_menuu:



             //   startActivity(new Intent(this,MainActivity.class));



            //case R.id.my_profile:

              //  startActivity(new Intent(this, ProfileActivity.class));





                default:
                    return super.onOptionsItemSelected(item);


        }

    }
}
