package com.example.unipigrades;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Toast;

public class AddEditNoteActivity extends AppCompatActivity {
    public static final String EXTRA_ID=
            "com.example.unipigrades.EXTRA_ID";
    public static final String EXTRA_TITLE=
            "com.example.unipigrades.EXTRA_TITLE";
    public static final String EXTRA_DESCRIPTION=
            "com.example.unipigrades.EXTRA_DESCRIPTION";
    public static final String EXTRA_PRIORITY=
            "com.example.unipigrades.EXTRA_PRIORITY";
    public static final String EXTRA_GRADE=
            "com.example.unipigrades.EXTRA_GRADE";
    public static final String EXTRA_PROJECTS=
            "com.example.unipigrades.EXTRA_PROJECTS";
    public static final String EXTRA_SEMESTER=
            "com.example.unipigrades.EXTRA_SEMESTER";
    public static final String EXTRA_ECTS=
            "com.example.unipigrades.EXTRA_ECTS";

    private EditText editTextTitle;
    private EditText editTextDescription;
    private NumberPicker numberPickerPriority;
    private NumberPicker numberPickerGrade;
    private EditText editTextProjects;
    private NumberPicker numberPickerSemester;
    private NumberPicker numberPickerEcts;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        editTextTitle = findViewById(R.id.edit_text_title);
        editTextDescription = findViewById(R.id.edit_text_description);
        editTextProjects=findViewById(R.id.edit_text_projects);
        numberPickerPriority = findViewById(R.id.number_picker_priority);

        numberPickerPriority.setMinValue(1);
        numberPickerPriority.setMaxValue(10);

        numberPickerGrade=findViewById(R.id.number_picker_grade);

        numberPickerGrade.setMinValue(1);
        numberPickerGrade.setMaxValue(10);

        numberPickerSemester=findViewById(R.id.number_picker_semester);
        numberPickerSemester.setMinValue(1);
        numberPickerSemester.setMaxValue(8);

        numberPickerEcts=findViewById(R.id.number_picker_ects);
        numberPickerEcts.setMinValue(1);
        numberPickerEcts.setMaxValue(15);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);
        Intent intent = getIntent();

        if (intent.hasExtra(EXTRA_ID)){
            setTitle("Edit note");
            editTextTitle.setText(intent.getStringExtra(EXTRA_TITLE));
            editTextDescription.setText(intent.getStringExtra(EXTRA_DESCRIPTION));
            editTextProjects.setText(intent.getStringExtra(EXTRA_PROJECTS));
            numberPickerPriority.setValue(intent.getIntExtra(EXTRA_PRIORITY, 1));
            numberPickerGrade.setValue(intent.getIntExtra(EXTRA_GRADE, 1));
            numberPickerSemester.setValue(intent.getIntExtra(EXTRA_SEMESTER,1));
            numberPickerEcts.setValue(intent.getIntExtra(EXTRA_ECTS,1));
        }else {
            setTitle("Add Note"); }

    }

    private void saveNote(){
        String title = editTextTitle.getText().toString();
        String description = editTextDescription.getText().toString();
        String projects= editTextProjects.getText().toString();
        int priority = numberPickerPriority.getValue();
        int grade = numberPickerGrade.getValue();
        int semester = numberPickerSemester.getValue();
        int ects = numberPickerEcts.getValue();

        if (title.trim().isEmpty()|| description.trim().isEmpty()){
            Toast.makeText(this, "Please insert a Title and a Description", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent data = new Intent();
        data.putExtra(EXTRA_TITLE, title);
        data.putExtra(EXTRA_DESCRIPTION, description);
        data.putExtra(EXTRA_PROJECTS , projects);
        data.putExtra(EXTRA_PRIORITY , priority);
        data.putExtra(EXTRA_GRADE, grade);
        data.putExtra(EXTRA_SEMESTER,semester);
        data.putExtra(EXTRA_ECTS,semester);

        int id = getIntent().getIntExtra(EXTRA_ID, -1);
        if (id!=1) {
            data.putExtra(EXTRA_ID, id);
        }


        setResult(RESULT_OK, data);
        finish();



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_note_menu, menu);

        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_note:
                saveNote();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
