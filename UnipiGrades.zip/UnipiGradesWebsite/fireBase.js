var app_fireBase = {};
(function(){
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDPvaTfngzBwvpXiSCmjEnOOaaUlmvgsZQ",
    authDomain: "unipigrades-app.firebaseapp.com",
    databaseURL: "https://unipigrades-app.firebaseio.com",
    projectId: "unipigrades-app",
    storageBucket: "unipigrades-app.appspot.com",
    messagingSenderId: "657889037842"
  };
  firebase.initializeApp(config);

  app_fireBase= firebase;





})()